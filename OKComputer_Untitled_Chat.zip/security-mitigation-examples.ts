/**
 * Garage Copilot - Security Hardening Examples
 * 
 * These are production-ready code snippets that implement the
 * security mitigations recommended in the security analysis report.
 * 
 * Copy these into your Electron main process, preload, and renderer code.
 */

// ============================================================================
// 1. MAIN PROCESS HARDENING (main.ts)
// ============================================================================

import { app, BrowserWindow, session, dialog, shell, ipcMain } from 'electron';
import * as path from 'path';
import { createHash } from 'crypto';

// Track approved serial devices for permission management
const approvedSerialDevices = new Set<string>();

function createSecureWindow(): BrowserWindow {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,           // SECURITY: Isolate renderer from Node.js
      nodeIntegration: false,           // SECURITY: Disable Node.js in renderer
      sandbox: true,                    // SECURITY: Enable Chromium sandbox
      webSecurity: true,                // SECURITY: Explicitly enable (default)
      allowRunningInsecureContent: false, // SECURITY: Explicitly disable (default)
      experimentalFeatures: false,      // SECURITY: Disable experimental features
      enableBlinkFeatures: '',          // SECURITY: No Blink features enabled
    }
  });

  // Configure Content Security Policy via HTTP header
  session.defaultSession.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self'; " +
          "script-src 'self'; " +
          "style-src 'self' 'unsafe-inline'; " +  // 'unsafe-inline' often needed for CSS
          "img-src 'self' data:; " +
          "font-src 'self'; " +
          "connect-src 'none'; " +           // Block all network requests from renderer
          "object-src 'none'; " +            // Block plugins
          "base-uri 'self'; " +              // Restrict base tag
          "form-action 'none';"             // Block form submissions
        ]
      }
    });
  });

  // Navigation hardening - prevent unwanted navigation
  app.on('web-contents-created', (_, contents) => {
    // Block all external navigation
    contents.on('will-navigate', (event, url) => {
      const parsedUrl = new URL(url);
      // Only allow file:// protocol (local app files)
      if (parsedUrl.protocol === 'file:') {
        return;
      }
      console.warn(`[Security] Blocked navigation to: ${url}`);
      event.preventDefault();
    });

    // Block all redirects
    contents.on('will-redirect', (event, url) => {
      console.warn(`[Security] Blocked redirect to: ${url}`);
      event.preventDefault();
    });
  });

  // Hardened external URL handling
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (isAllowedExternalUrl(url)) {
      void shell.openExternal(url);
    } else {
      console.warn(`[Security] Blocked external URL: ${url}`);
    }
    return { action: 'deny' };  // Always deny - open in OS browser instead
  });

  // Permission handlers
  setupPermissionHandlers();

  return win;
}

/**
 * Validates external URLs against an allowlist
 */
function isAllowedExternalUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    
    // Strict HTTPS-only
    if (parsed.protocol !== 'https:') return false;
    
    // Allowlist of trusted domains
    const allowedDomains = [
      'github.com',
      'github.io',
      'electronjs.org',
    ];
    
    return allowedDomains.some(domain => 
      parsed.hostname === domain || 
      parsed.hostname.endsWith(`.${domain}`)
    );
  } catch {
    return false;
  }
}

/**
 * Sets up all permission handlers for the session
 */
function setupPermissionHandlers(): void {
  // Serial device permission - require explicit user consent
  session.defaultSession.setDevicePermissionHandler((details) => {
    if (details.deviceType !== 'serial') return false;
    
    // Already approved
    if (approvedSerialDevices.has(details.device.deviceId)) return true;
    
    // Show consent dialog
    const result = dialog.showMessageBoxSync({
      type: 'question',
      buttons: ['Allow', 'Deny'],
      message: 'Allow Serial Device Access?',
      detail: `Garage Copilot wants to access:\n` +
              `Device: ${details.device.name}\n` +
              `Serial Number: ${details.device.serialNumber || 'N/A'}`,
      noLink: true
    });
    
    const approved = result === 0;
    if (approved) {
      approvedSerialDevices.add(details.device.deviceId);
    }
    return approved;
  });

  // General permission check - only allow serial
  session.defaultSession.setPermissionCheckHandler((_wc, permission) => {
    return permission === 'serial';
  });

  // Permission request handler - deny all except serial
  session.defaultSession.setPermissionRequestHandler(
    (_webContents, permission, callback) => {
      const allowedPermissions = new Set(['serial']);
      const allowed = allowedPermissions.has(permission);
      
      if (!allowed) {
        console.warn(`[Security] Denied permission request: ${permission}`);
      }
      
      callback(allowed);
    }
  );
}

// ============================================================================
// 2. IPC SENDER VALIDATION
// ============================================================================

interface SerialPortInfo {
  portId: string;
  name: string;
}

// Hardened IPC handler with sender validation
ipcMain.handle('garage:getSerialPorts', (event): SerialPortInfo[] => {
  // Validate sender origin
  const sender = event.senderFrame;
  if (!sender || !sender.origin.startsWith('file://')) {
    console.warn('[Security] Blocked IPC from unauthorized sender:', sender?.origin);
    throw new Error('Unauthorized IPC sender');
  }
  
  // ... return serial ports
  return [];
});

ipcMain.handle('garage:chooseSerialPort', (event, portId: string) => {
  const sender = event.senderFrame;
  if (!sender || !sender.origin.startsWith('file://')) {
    throw new Error('Unauthorized IPC sender');
  }
  
  // Validate portId format to prevent injection
  if (!/^[a-zA-Z0-9_-]+$/.test(portId)) {
    throw new Error('Invalid port ID format');
  }
  
  // ... handle port selection
});

// ============================================================================
// 3. OBD-II SECURITY UTILITIES
// ============================================================================

// Maximum safe response size to prevent DoS from malicious adapter
const MAX_RESPONSE_BYTES = 4096;

// Blocked OBD-II commands that must never be sent
const BLOCKED_COMMANDS: Array<string | RegExp> = [
  /^08/,       // Mode 08: Bidirectional Control (DANGEROUS)
  /^04/,       // Mode 04: Clear Codes (write operation)
  'ATMA',      // Monitor All - CAN traffic dump
  'ATMR',      // Monitor Receiver
  'ATMT',      // Monitor Transmitter
  'ATPC',      // Protocol Close
];

/**
 * Validates that an OBD-II command is safe to send
 */
export function isObdCommandAllowed(command: string): boolean {
  const normalized = command.trim().toUpperCase();
  
  return !BLOCKED_COMMANDS.some(blocked => {
    if (typeof blocked === 'string') {
      return normalized === blocked;
    }
    return blocked.test(normalized);
  });
}

/**
 * Safely decodes DTC bytes with input validation
 */
export function decodeDtcSafe(a: number, b: number): string | null {
  // Validate inputs are valid bytes
  if (!Number.isInteger(a) || !Number.isInteger(b)) return null;
  if (a < 0 || a > 0xFF || b < 0 || b > 0xFF) return null;
  
  // First nibble determines DTC category
  const categoryNibble = (a >> 6) & 0x03;
  const category = ['P', 'C', 'B', 'U'][categoryNibble];
  
  if (!category) return null;
  
  // Extract digits safely
  const digit2 = (a >> 4) & 0x03;
  const digit3 = a & 0x0F;
  const digit4 = (b >> 4) & 0x0F;
  const digit5 = b & 0x0F;
  
  return `${category}${digit2}${digit3.toString(16)}${digit4.toString(16)}${digit5.toString(16)}`.toUpperCase();
}

/**
 * Validates raw OBD-II response before parsing
 */
export function validateObdResponse(response: string): boolean {
  // Check for reasonable length
  if (response.length === 0 || response.length > MAX_RESPONSE_BYTES * 2) {
    return false;
  }
  
  // Check for valid hex characters and formatting
  const validChars = /^[0-9A-Fa-f\s\r\n]+$/;
  if (!validChars.test(response)) {
    return false;
  }
  
  return true;
}

// ============================================================================
// 4. VIN PRIVACY UTILITIES
// ============================================================================

/**
 * Anonymizes a VIN for export (shows first 14 chars, masks last 3)
 */
export function anonymizeVin(vin: string): string {
  if (vin.length !== 17) return vin;  // Invalid VIN, return as-is
  return vin.substring(0, 14) + '***';
}

/**
 * Checks if a string is a valid VIN format
 */
export function isValidVin(vin: string): boolean {
  // VIN must be exactly 17 characters
  if (!vin || vin.length !== 17) return false;
  
  // VIN uses only specific characters (no I, O, Q)
  const validVinChars = /^[A-HJ-NPR-Z0-9]{17}$/;
  return validVinChars.test(vin);
}

// ============================================================================
// 5. RENDERER-SIDE SECURITY UTILITIES
// ============================================================================

/**
 * Securely downloads text data as a file
 * Fixes the race condition in URL.revokeObjectURL
 */
export function downloadTextSecure(data: string, filename: string, mime: string): void {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  
  document.body.appendChild(a);
  a.click();
  
  // Reliable cleanup using double rAF
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  });
}

/**
 * Shows privacy consent dialog for VIN collection
 */
export interface PrivacyConsentResult {
  granted: boolean;
  anonymizeExports: boolean;
  doNotAskAgain: boolean;
}

export async function showVinPrivacyConsent(): Promise<PrivacyConsentResult> {
  // In a real app, this would show a modal dialog
  // For now, return a typed interface
  return {
    granted: true,
    anonymizeExports: false,
    doNotAskAgain: false
  };
}

// ============================================================================
// 6. ELECTRON BUILDER SECURITY CONFIG
// ============================================================================

/**
 * Recommended electron-builder.yml additions for security:
 * 
 * ```yaml
 * appId: com.cbaileydev.garage-copilot
 * productName: Garage Copilot
 * 
 * # ASAR integrity
 * asar: true
 * asarUnpack: []
 * 
 * directories:
 *   output: dist-electron
 * 
 * files:
 *   - dist/**/*
 *   - package.json
 * 
 * mac:
 *   category: public.app-category.utilities
 *   target: dmg
 *   hardenedRuntime: true
 *   gatekeeperAssess: false
 *   entitlements: build/entitlements.mac.plist
 *   entitlementsInherit: build/entitlements.mac.plist
 *   signIgnore: []
 * 
 * win:
 *   target: nsis
 *   verifyUpdateCodeSignature: true
 *   # signingHashAlgorithms: ['sha256']
 *   # sign: ./build-scripts/custom-sign.js  # For cloud HSM signing
 * 
 * # Future: Auto-updater with security
 * # publish:
 * #   provider: github
 * #   owner: cbaileydev
 * #   repo: garage-copilot
 * #   private: false
 * ```
 */

// ============================================================================
// 7. MACOS ENTITLEMENTS (build/entitlements.mac.plist)
// ============================================================================

/**
 * Contents of build/entitlements.mac.plist:
 * 
 * <?xml version="1.0" encoding="UTF-8"?>
 * <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
 * <plist version="1.0">
 * <dict>
 *   <key>com.apple.security.cs.allow-jit</key>
 *   <true/>
 *   <key>com.apple.security.cs.allow-unsigned-executable-memory</key>
 *   <true/>
 *   <key>com.apple.security.cs.allow-dyld-environment-variables</key>
 *   <false/>
 *   <key>com.apple.security.cs.disable-library-validation</key>
 *   <false/>
 *   <key>com.apple.security.cs.debugger</key>
 *   <false/>
 *   <key>com.apple.security.device.serial</key>
 *   <true/>
 * </dict>
 * </plist>
 */

// ============================================================================
// 8. GITHUB ACTIONS CI SECURITY
// ============================================================================

/**
 * Recommended .github/workflows/security.yml:
 * 
 * ```yaml
 * name: Security Audit
 * 
 * on:
 *   push:
 *     branches: [main]
 *   pull_request:
 *     branches: [main]
 *   schedule:
 *     - cron: '0 0 * * 0'  # Weekly
 * 
 * jobs:
 *   audit:
 *     runs-on: ubuntu-latest
 *     steps:
 *       - uses: actions/checkout@v4
 *       
 *       - name: Setup Node.js
 *         uses: actions/setup-node@v4
 *         with:
 *           node-version: '20'
 *           cache: 'npm'
 *       
 *       - name: Install dependencies
 *         run: npm ci
 *       
 *       - name: Run npm audit
 *         run: npm audit --audit-level=moderate
 *         continue-on-error: false
 *       
 *       - name: Check for outdated packages
 *         run: npm outdated
 *         continue-on-error: true
 * ```
 */

export {
  createSecureWindow,
  setupPermissionHandlers,
  isAllowedExternalUrl,
  isObdCommandAllowed,
  decodeDtcSafe,
  validateObdResponse,
  anonymizeVin,
  isValidVin,
  downloadTextSecure,
};
