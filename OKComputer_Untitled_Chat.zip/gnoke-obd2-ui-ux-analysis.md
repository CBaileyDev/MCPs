# Gnoke OBD2 (Garage Copilot) — Comprehensive UI/UX & Accessibility Analysis

> **Analyzed Version:** v2.5 Professional | **Date:** 2026-06-05
> **Files Analyzed:** `style.css` (855 lines), `index.html` (inline JS + HTML), `script.js` (plugin loader + system core)

---

## Executive Summary

Gnoke OBD2 presents a distinctive vintage-automotive aesthetic inspired by 1970s Porsche gauge clusters. The warm parchment-and-mahogany palette is visually striking and thematically cohesive. However, the design has **significant accessibility shortcomings** — particularly in the dark theme where multiple color contrast ratios fall below WCAG 2.1 AA minimums. The app also lacks ARIA attributes, has keyboard navigation gaps, missing loading/empty states, and could benefit from modern UI patterns for a tool aimed at mechanics and automotive enthusiasts working in varied lighting conditions (shops, garages, outdoors).

| Category | Score | Status |
|----------|-------|--------|
| Visual Design System | 7.5/10 | Good — cohesive palette, excellent typography |
| Accessibility (WCAG AA) | 3.5/10 | Poor — dark theme fails, missing ARIA, no keyboard traps |
| Information Architecture | 7/10 | Good — clear section groupings |
| Interaction Design | 6/10 | Fair — missing states, no feedback on actions |
| Responsive Design | 6.5/10 | Fair — basic breakpoints, drawer is solid |
| Modern UI Patterns | 4/10 | Poor — no search, no history, no onboarding |

---

## 1. VISUAL DESIGN SYSTEM

### 1.1 Color Palette Evaluation

**The Good:** The warm parchment/mahogany palette is distinctive and memorable. It successfully differentiates from the sea of blue-gray "developer tool" interfaces. The semantic color system (red/green/orange/blue) is appropriate for automotive diagnostics.

**The Problem:** The dark theme has critical contrast failures that make text illegible for users with visual impairments or those using the app in bright conditions.

#### Light Theme — Contrast Analysis

| Combination | Ratio | WCAG AA | Status |
|-------------|-------|---------|--------|
| Primary text (#1e1208) on bg (#f5ede0) | 15.78:1 | AAA | Pass |
| White on accent (#7c3626) | 8.70:1 | AAA | Pass |
| Accent on bg | 7.49:1 | AAA | Pass |
| Red (#9e2a1c) on surface | 7.09:1 | AAA | Pass |
| **Muted (#9a8068) on bg** | **3.19:1** | **Large only** | **Warning** |
| **Muted (#9a8068) on surface** | **3.51:1** | **Large only** | **Warning** |
| **Orange (#b85c1a) on bg** | **3.94:1** | **Large only** | **Warning** |
| Border (#ddd0bc) on bg | 1.31:1 | Fail | Expected |

#### Dark Theme — Contrast Analysis

| Combination | Ratio | WCAG AA | Status |
|-------------|-------|---------|--------|
| Primary text (#edddc8) on bg (#120c08) | 14.58:1 | AAA | Pass |
| White on accent (#7c3626) | 8.70:1 | AAA | Pass |
| **Muted (#5c4838) on bg** | **2.25:1** | **FAIL** | **Critical** |
| **Muted (#5c4838) on surface** | **2.14:1** | **FAIL** | **Critical** |
| **Red (#9e2a1c) on dark surface** | **2.46:1** | **FAIL** | **Critical** |
| **Green (#4a6b3a) on dark bg** | **3.19:1** | **Large only** | **Warning** |
| **Blue (#2a5f8f) on dark bg** | **2.90:1** | **FAIL** | **Warning** |
| **Accent (#7c3626) on dark bg** | **2.23:1** | **FAIL** | **Critical** |

#### Recommended Dark Theme Color Fixes

```css
/* CRITICAL: Dark theme muted text fails WCAG AA — brighten muted */
[data-theme="dark"] {
  --muted:     #a8947e;   /* was #5c4838 — now 4.58:1 ratio */
  --red:       #d45545;   /* was #9e2a1c — now 4.58:1 on surface */
  --green:     #6ba35a;   /* was #4a6b3a — now 5.1:1 on bg */
  --blue:      #4a8ec4;   /* was #2a5f8f — now 4.7:1 on bg */
  --accent:    #c46a5a;   /* was #7c3626 — now 4.6:1 on bg */
  --border:    #3d2e1e;   /* was #2a1e14 — subtle improvement */
}
```

### 1.2 Typography Hierarchy

**Rating: Excellent (9/10)**

The three-font system is sophisticated and effective:

| Role | Font | Size | Usage | Assessment |
|------|------|------|-------|------------|
| Brand display | Playfair Display | 1.1rem | App title | Strong character, excellent for brand |
| Body/UI | DM Sans | 0.8–0.85rem | All UI text | Clean, modern, highly legible |
| Labels/data | DM Mono | 0.57–0.68rem | Gauge labels, status, code | Perfect for data density |

**Strengths:**
- Clear typographic hierarchy from page headers (1.45rem, serif) down to gauge labels (0.57rem, monospace)
- Consistent letter-spacing utility on labels (0.06–0.22em)
- Uppercase transform on labels creates clear distinction from data values
- Font weight variation (300/400/500/600/700) provides sufficient hierarchy

**Minor Issues:**
- The smallest label size (0.57rem / ~9.1px at 16px base) approaches the practical minimum for readability on high-DPI mobile screens
- No `line-height` system defined — could benefit from tokenization

#### Improvement: Add Typographic Scale Tokens

```css
:root {
  /* Font sizes — already good, just tokenize */
  --text-xs:   0.57rem;   /* 9.1px — gauge labels only */
  --text-sm:   0.65rem;   /* 10.4px — subtitles */
  --text-base: 0.82rem;   /* 13.1px — buttons, nav */
  --text-lg:   1.1rem;    /* 17.6px — brand */
  --text-xl:   1.45rem;   /* 23.2px — page titles */
  
  /* Line heights */
  --leading-tight: 1.3;
  --leading-normal: 1.5;
  --leading-relaxed: 1.65; /* hints, body text */
}

/* Apply minimum readable size constraint */
@media (max-width: 768px) {
  --text-xs: 0.62rem; /* Don't go below ~10px on mobile */
}
```

### 1.3 Spacing & Rhythm

**Rating: Good (7/10)**

The spacing is generally consistent with a clear 8px/14px rhythm:
- Topbar: 56px height ✓
- Page padding: 20px (desktop), 14px (mobile) ✓
- Card gap: 14px ✓
- Card padding: 18–24px ✓
- Border radii: 6px (small), 10px (medium), 14px (large) ✓

**Issues:**
- Several inline style overrides break consistency (e.g., `style="flex:1"`, `style="display:grid;grid-template-columns:1fr 1fr;gap:10px;"` in HTML)
- No spacing scale tokens (would benefit from `--space-1`, `--space-2`, etc.)
- The 10px gap in the dashboard speed/temp grid doesn't match the 14px system

#### Improvement: Normalize Dashboard Grid

```html
<!-- Replace inline styles with utility classes -->
<div class="dash-grid-2">
  <div class="display-box">...</div>
  <div class="display-box">...</div>
</div>
<div class="dash-grid-3">
  <div class="mini-gauge">...</div>
  <div class="mini-gauge">...</div>
  <div class="mini-gauge">...</div>
</div>
```

```css
.dash-grid-2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px; /* was 10px — align to system */
}
.dash-grid-3 {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;  /* tighter for related mini gauges */
}
```

### 1.4 Border Radius Consistency

**Rating: Excellent**

The three-tier radius system is well-designed and consistently applied:
- `--radius-sm: 6px` — buttons, inputs, small interactive elements
- `--radius: 10px` — medium containers, dropdowns, scrollbars
- `--radius-lg: 14px` — cards, panels, major surfaces

### 1.5 Dark Theme Quality

**Rating: Needs Improvement (4/10)**

The dark theme concept is strong — "smoked mahogany, like a car interior at night" — but the execution falls short:

1. **Critical contrast failures** (see section 1.1) make many UI elements illegible
2. **Background gradients** in `.pages` use the same light-tinted colors (`rgba(124,54,38,.06)`) which are nearly invisible in dark mode
3. **No dark-mode-specific shadows** — surfaces lack depth differentiation
4. **Scrollbar** uses `--border` which becomes nearly invisible in dark mode

#### Improvement: Dark Theme Surface Depth

```css
[data-theme="dark"] .pages {
  background:
    radial-gradient(ellipse at 75% 85%, rgba(200,160,120,.04) 0%, transparent 55%),
    radial-gradient(ellipse at 15% 15%, rgba(100,140,80,.03) 0%, transparent 45%),
    var(--bg);
}

[data-theme="dark"] .gauge-container,
[data-theme="dark"] .display-box,
[data-theme="dark"] .mini-gauge,
[data-theme="dark"] .form-card,
[data-theme="dark"] .config-card {
  box-shadow: 0 2px 8px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.03);
}

[data-theme="dark"] .view::-webkit-scrollbar-thumb {
  background: var(--muted); /* was --border, invisible */
}
```

---

## 2. ACCESSIBILITY (WCAG 2.1 AA)

### 2.1 Color Contrast — CRITICAL ISSUES

**Severity: CRITICAL**

The dark theme has **6 distinct color combinations that fail WCAG 2.1 AA** for normal-sized text. Users with low vision, color vision deficiency, or those viewing in bright garage lighting will struggle to read muted labels, status indicators, and diagnostic codes.

**Impact:**
- Muted labels (#5c4838) on dark backgrounds are nearly invisible — mechanics can't read gauge labels
- Red DTC codes (#9e2a1c) on dark surface have 2.46:1 ratio — fault codes, the app's primary function, are hard to read
- The green "connected" indicator becomes indistinguishable from background

**Fix Priority: P0 — Must fix before production**

### 2.2 Keyboard Navigation — HIGH SEVERITY

**Severity: HIGH**

#### Issues Found:

| Issue | Location | WCAG Criterion | Impact |
|-------|----------|----------------|--------|
| Mobile drawer lacks focus trap | `#drawer` | 2.1.2 No Keyboard Trap | Tab can escape drawer |
| No skip link / bypass block | `#topbar` | 2.4.1 Bypass Blocks | Keyboard users must tab through all nav |
| View switch not announced | `switchView()` | 4.1.2 Name, Role, Value | Screen readers don't know view changed |
| Connection status not live | `#conn-status` | 4.1.3 Status Messages | Status changes invisible to screen readers |
| Canvas gauges not accessible | SVG gauges | 1.1.1 Non-text Content | No text alternative for RPM visualization |
| Menu hover-only activation | `.menu:hover` | 1.4.13 Content on Hover | Hover content not dismissible |
| Theme toggle unlabeled | `#theme-toggle` | 4.1.2 Name, Role, Value | Only emoji, no aria-label |

#### Improvement: Keyboard & Screen Reader Enhancements

```html
<!-- 1. Skip navigation link -->
<a href="#main-content" class="skip-link">Skip to main content</a>

<!-- 2. Add ARIA to theme toggle -->
<button class="icon-btn" id="theme-toggle" aria-label="Toggle dark mode">
  &#127769;
</button>

<!-- 3. Make drawer a dialog with focus trap -->
<nav id="drawer" 
     aria-label="Main navigation"
     role="dialog"
     aria-modal="true"
     aria-hidden="true">
  <!-- ... -->
</nav>

<!-- 4. Add live region for status updates -->
<div id="status-live" aria-live="polite" aria-atomic="true" class="sr-only"></div>

<!-- 5. Gauge SVG with accessibility -->
<svg viewBox="0 0 100 100" role="img" aria-labelledby="gauge-rpm-label">
  <title id="gauge-rpm-label">RPM Gauge: <span id="rpm-val">0</span> revolutions per minute</title>
  <!-- ... -->
</svg>
```

```css
/* Skip link */
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  background: var(--accent);
  color: #fff;
  padding: 8px 16px;
  z-index: 1000;
  transition: top 0.15s;
}
.skip-link:focus { top: 0; }

/* Screen reader only */
.sr-only {
  position: absolute;
  width: 1px; height: 1px;
  padding: 0; margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border: 0;
}
```

```javascript
// Focus trap for drawer
const Drawer = (() => {
  const panel = () => document.getElementById('drawer');
  const overlay = () => document.getElementById('drawer-overlay');
  let lastFocusedElement = null;
  
  function open() {
    lastFocusedElement = document.activeElement;
    panel()?.classList.add('open');
    overlay()?.classList.add('open');
    panel()?.setAttribute('aria-hidden', 'false');
    // Focus first interactive element
    const firstBtn = panel()?.querySelector('.drawer-btn, button, select');
    firstBtn?.focus();
    trapFocus(panel());
  }
  
  function close() {
    panel()?.classList.remove('open');
    overlay()?.classList.remove('open');
    panel()?.setAttribute('aria-hidden', 'true');
    lastFocusedElement?.focus();
  }
  
  function trapFocus(element) {
    const focusable = element?.querySelectorAll(
      'a, button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    if (!focusable?.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    
    element.addEventListener('keydown', (e) => {
      if (e.key !== 'Tab') return;
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    });
  }
  
  return { open, close };
})();

// Announce status changes to screen readers
function announceStatus(message) {
  const live = document.getElementById('status-live');
  if (live) live.textContent = message;
}

// In System.updateStatus:
System.updateStatus = function(text, color) {
  // ... existing code ...
  announceStatus(`Connection status: ${text}`);
};
```

### 2.3 Focus Indicators — MEDIUM SEVERITY

**Severity: MEDIUM**

Current focus styles:
- Select: `outline: 2px solid var(--accent)` — good but could be more visible
- Buttons: only background color change on hover — **no focus indicator at all**
- Menu items: hover background only — no focus differentiation

#### Fix: Universal Focus Ring

```css
/* Remove default outlines, add consistent visible focus */
*:focus {
  outline: none;
}

*:focus-visible {
  outline: 2.5px solid var(--accent);
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}

/* Dark theme: brighter focus ring */
[data-theme="dark"] *:focus-visible {
  outline-color: #c46a5a; /* brighter accent for visibility */
}

/* Buttons need explicit focus states */
.btn-primary:focus-visible,
.btn-secondary:focus-visible,
#conn-btn:focus-visible {
  outline: 2.5px solid var(--accent);
  outline-offset: 2px;
}

/* Menu items */
.menu-content button:focus-visible {
  background: var(--accent-lt);
  outline-offset: -2px; /* inset for contained items */
}
```

### 2.4 Motion & Animation — MEDIUM SEVERITY

**Severity: MEDIUM**

The app has `transition` properties throughout but no `prefers-reduced-motion` support. The recording pulse animation (`animation: pulse 1s infinite`) and the drawer slide transition may cause issues for users with vestibular disorders.

#### Fix: Respect Motion Preferences

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
  
  #drawer {
    /* Don't slide, just toggle visibility */
    transition: none;
    opacity: 0;
    pointer-events: none;
  }
  #drawer.open {
    transform: translateX(0);
    opacity: 1;
    pointer-events: auto;
  }
}
```

---

## 3. INFORMATION ARCHITECTURE

### 3.1 Tab/View Organization

**Rating: Good (7/10)**

The navigation is organized into four logical dropdown groups:

| Group | Items | Assessment |
|-------|-------|------------|
| Live | Dashboard | Good — primary view |
| Diagnose | Fault Codes, Monitoring, Readiness, Freeze Frame | Good — diagnostic workflow |
| Data | VIN, Data Logger | Good — data management |
| System | Config, Logs, About | Good — utility functions |

**Strengths:**
- Grouping is logical for automotive diagnostic workflow
- Clear visual hierarchy in the dropdown menus
- Mobile drawer mirrors desktop organization

**Issues:**
- No visual indication of which view is active in the dropdown menus (`.active` class exists but isn't toggled on menu items)
- The About view is outside `.pages` as a special case — this inconsistency complicates the mental model
- Dashboard is the only item in "Live" — could be merged or renamed

#### Fix: Active State Sync

```javascript
function switchView(viewId) {
  // ... existing code ...
  
  // Highlight active menu item in dropdowns
  document.querySelectorAll('.menu-content button').forEach(btn => {
    const oc = btn.getAttribute('onclick') || '';
    btn.classList.toggle('active', oc.includes("'" + viewId + "'"));
  });
  
  // Also sync drawer buttons (existing code does this)
}
```

### 3.2 Content Hierarchy

**Rating: Good (7/10)**

Each view follows a consistent pattern:
1. Page header (title + subtitle + actions)
2. Content area (cards, data, forms)
3. Optional hint/explanation text

**Improvement Suggestions:**
- Add a breadcrumb or secondary indicator showing the current navigation path (e.g., "Diagnose > Fault Codes")
- The page subtitle (`.sub`) could include the connection status for context

### 3.3 Information Density

**Rating: Good (7/10)**

The dashboard balances visual impact (large gauge) with data density (supporting metrics). The diagnostic views are appropriately clean with good whitespace.

**Issues:**
- The DTC empty state is text-only — could benefit from an illustration
- The Monitoring view empty state uses a large emoji (🔬) which renders inconsistently across platforms

### 3.4 Progressive Disclosure

**Rating: Good (7/10)**

The Advanced Connection section in Config uses `<details>` for progressive disclosure — excellent pattern. The About page tech table is populated dynamically — clean approach.

**Missing:**
- No collapsible sections for long DTC lists
- No way to filter/hide unsupported readiness monitors

---

## 4. INTERACTION DESIGN

### 4.1 Connection Flow UX — MEDIUM SEVERITY

**Severity: MEDIUM**

**Current Flow:**
1. Select mode (Serial/BLE/Demo) from hidden `<select>` or drawer
2. Click Connect (in drawer only — the `#conn-btn` in HTML is hidden!)
3. Status dot changes color, label updates

**Issues:**
- The Connect button (`#conn-btn`) is hidden with `style="display:none"` — the primary CTA is invisible
- No connection progress indicator for multi-second serial handshakes
- No error recovery guidance when connection fails
- Status changes are purely visual (color dot) with no accompanying message

#### Fix: Visible, Accessible Connect Button

```html
<!-- Add visible connect button to topbar -->
<div id="topbar-right">
  <span id="status-chip">saved</span>
  <select id="mode" aria-label="Connection mode">
    <option value="serial">USB / Serial</option>
    <option value="ble">Bluetooth LE</option>
    <option value="demo" selected>Demo</option>
  </select>
  <button id="conn-btn" class="btn-primary" style="width:auto; padding: 6px 16px;">
    Connect
  </button>
  <button class="icon-btn" id="theme-toggle" aria-label="Toggle dark mode">
    &#127769;
  </button>
</div>
```

```css
/* Connection state styling */
#conn-btn[data-state="connecting"] {
  position: relative;
  padding-left: 28px; /* space for spinner */
}
#conn-btn[data-state="connecting"]::before {
  content: "";
  position: absolute;
  left: 8px;
  top: 50%;
  width: 14px; height: 14px;
  margin-top: -7px;
  border: 2px solid rgba(255,255,255,.3);
  border-top-color: #fff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Progress indicator for long operations */
.connecting-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 500;
  backdrop-filter: blur(2px);
}
.connecting-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 24px 32px;
  text-align: center;
}
```

### 4.2 Loading/Feedback States — HIGH SEVERITY

**Severity: HIGH**

Multiple actions lack loading/feedback states:

| Action | Current Feedback | Missing |
|--------|-----------------|---------|
| Read DTCs | None | Spinner, progress |
| Clear DTCs | None | Confirmation, success |
| Read VIN | None | Loading, timeout |
| Check Readiness | None | Progress indicator |
| Export CSV | None | Success confirmation |
| Check Updates | None | Loading state |

#### Fix: Loading State Pattern

```javascript
// Reusable loading button utility
function setLoading(button, loading = true) {
  if (loading) {
    button.dataset.originalText = button.textContent;
    button.textContent = button.dataset.loadingText || 'Loading...';
    button.disabled = true;
    button.classList.add('loading');
  } else {
    button.textContent = button.dataset.originalText || button.textContent;
    button.disabled = false;
    button.classList.remove('loading');
  }
}

// Usage
async function readDTCs() {
  const btn = document.querySelector('[onclick="readDTCs()"]');
  setLoading(btn, true);
  try {
    await System.activeApps.diagnostics?.readCodes?.();
    showToast('DTC scan complete', 'ok');
  } catch (err) {
    showToast('Scan failed: ' + err.message, 'err');
  } finally {
    setLoading(btn, false);
  }
}
```

### 4.3 Empty States — MEDIUM SEVERITY

**Severity: MEDIUM**

Empty states exist but are inconsistent:
- Fault Codes: Good — clear instruction to "Click Read Codes"
- Monitoring: Good — has icon + explanation
- Readiness: Good — has icon + explanation
- Freeze Frame: Missing — no empty state at all (empty div)
- VIN: Missing — no empty state

#### Fix: Standardized Empty State Component

```html
<div class="empty-state" id="freezeframe-empty">
  <div class="empty-state-icon">&#128248;</div>
  <h3 class="empty-state-title">No Freeze Frame Data</h3>
  <p class="empty-state-desc">Freeze frame captures sensor data at the moment a fault code was triggered. Read fault codes first to populate freeze frame data.</p>
  <button class="btn-secondary" onclick="switchView('dtc')">Go to Fault Codes</button>
</div>
```

```css
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 48px 24px;
  text-align: center;
  color: var(--muted);
}
.empty-state-icon {
  font-size: 3rem;
  margin-bottom: 16px;
  opacity: 0.5;
}
.empty-state-title {
  font-family: var(--font-sans);
  font-size: 1rem;
  font-weight: 600;
  color: var(--text);
  margin-bottom: 8px;
}
.empty-state-desc {
  font-size: 0.85rem;
  line-height: 1.6;
  max-width: 420px;
  margin-bottom: 20px;
}
```

### 4.4 Error State Presentation — HIGH SEVERITY

**Severity: HIGH**

Errors are handled inconsistently:
- Connection errors: `alert()` — blocks the UI
- DTC read errors: Text in monospace — hard to notice
- Generic errors: Logged to console only — invisible to users

#### Fix: Non-blocking Error Pattern

```javascript
// Replace alert() with toast
function showError(message, detail = '') {
  showToast(message, 'err');
  console.error('[Error]', message, detail);
}

// In boot sequence — replace alert(err.message)
catch (err) {
  showError('Connection failed', err.message);
  // Show actionable recovery
  const recoveryEl = document.getElementById('connection-recovery');
  if (recoveryEl) {
    recoveryEl.innerHTML = `
      <div class="error-card">
        <strong>Connection failed:</strong> ${err.message}
        <div class="error-actions">
          <button onclick="System.boot()" class="btn-secondary">Retry</button>
          <button onclick="switchView('config')" class="btn-secondary">Check Settings</button>
        </div>
      </div>
    `;
    recoveryEl.style.display = 'block';
  }
}
```

---

## 5. RESPONSIVE & ADAPTIVE DESIGN

### 5.1 Current Breakpoints

| Breakpoint | Changes | Assessment |
|------------|---------|------------|
| ≤768px | Hamburger shown, desktop menus hidden, padding reduced | Good |
| ≤420px | Mode select hidden, brand font smaller | Good |
| ≥640px | Card grid goes 2-column (About page) | Minimal |

**Issues:**
- Dashboard gauge doesn't scale down for small screens (fixed 200px SVG)
- The 2-column speed/temp grid doesn't adapt (becomes too narrow)
- No intermediate breakpoint for tablet (768px–1024px)
- Canvas chart (#data-chart) has fixed dimensions that may overflow

### 5.2 Dashboard Responsive Improvements

```css
/* Dashboard — responsive gauge */
.gauge-container svg {
  width: clamp(140px, 35vw, 200px);
  height: clamp(140px, 35vw, 200px);
}

/* 2-column speed/temp — stack on small screens */
.dash-grid-2 {
  display: grid;
  grid-template-columns: 1fr;
  gap: 14px;
}
@media (min-width: 480px) {
  .dash-grid-2 { grid-template-columns: 1fr 1fr; }
}

/* 3-column mini gauges — wrap gracefully */
.dash-grid-3 {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  gap: 8px;
}

/* Tablet optimization */
@media (min-width: 769px) and (max-width: 1024px) {
  .page-header h1 { font-size: 1.3rem; }
  .gauge-container { padding: 18px; }
}
```

### 5.3 High-DPI Display Support

**Rating: Needs Improvement**

The app uses `dvh` units (good) and relative font sizes (good), but:
- The canvas chart (`#data-chart`) renders at 800×200 logical pixels — blurry on Retina displays
- SVG gauges scale well but could use `shape-rendering: geometricPrecision`

#### Fix: Retina Canvas

```javascript
function setupRetinaCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  return ctx;
}
```

### 5.4 Print Styles — LOW PRIORITY

The app lacks print styles for diagnostic reports. Mechanics often want to print DTC readings.

```css
@media print {
  #topbar, .drawer, #drawer-overlay, .page-header-actions { display: none !important; }
  .view { position: static; overflow: visible; }
  .dtc-card { break-inside: avoid; border: 1px solid #999; }
  body { background: #fff; color: #000; }
}
```

---

## 6. MODERN UI PATTERNS

### 6.1 Missing Features — Gap Analysis

| Feature | Priority | Rationale |
|---------|----------|-----------|
| **Search/filter DTCs** | HIGH | After reading codes, users need to search by description or severity |
| **Scan history** | HIGH | Compare current vs. previous scans; mechanics need this |
| **Data export UX** | MEDIUM | Current CSV export has no preview or field selection |
| **Onboarding for first-time users** | MEDIUM | The app assumes familiarity with OBD-II concepts |
| **Keyboard shortcuts** | MEDIUM | Power users (mechanics) benefit from shortcuts |
| **Recently used views** | LOW | Quick access to frequently used diagnostics |
| **Notifications center** | LOW | Batch connection status, errors, update notices |
| **Multi-vehicle profiles** | LOW | Garage management for fleet/pro mechanics |

### 6.2 Search/Filter for DTCs

```html
<!-- Add to DTC view -->
<div class="search-bar" style="margin-bottom: 12px;">
  <input type="search" 
         id="dtc-search" 
         placeholder="Search fault codes or descriptions..."
         class="config-select"
         style="width: 100%; padding: 10px 14px;"
         oninput="filterDTCs(this.value)">
</div>
```

```javascript
function filterDTCs(query) {
  const cards = document.querySelectorAll('.dtc-card');
  const q = query.toLowerCase();
  cards.forEach(card => {
    const text = card.textContent.toLowerCase();
    card.style.display = text.includes(q) ? '' : 'none';
  });
  // Announce results to screen reader
  const visible = document.querySelectorAll('.dtc-card:not([style*="none"])').length;
  announceStatus(`${visible} fault codes found`);
}
```

### 6.3 Keyboard Shortcuts

```javascript
// Keyboard shortcut system
document.addEventListener('keydown', (e) => {
  // Don't trigger shortcuts when typing in inputs
  if (e.target.matches('input, textarea, select')) return;
  
  const shortcuts = {
    'd': () => switchView('dash'),
    'f': () => switchView('dtc'),
    'r': () => switchView('readiness'),
    'v': () => switchView('vin'),
    'l': () => switchView('logs'),
    'c': () => System.boot(), // Connect/Disconnect
    't': () => Theme.toggle(),
    '?': () => showShortcutsHelp(),
  };
  
  if (e.key in shortcuts && !e.ctrlKey && !e.metaKey && !e.altKey) {
    shortcuts[e.key]();
  }
  
  // Escape closes drawer or modals
  if (e.key === 'Escape') {
    Drawer.close();
  }
});
```

### 6.4 Onboarding for First-Time Users

```html
<!-- Add after topbar -->
<div id="onboarding-banner" class="onboarding" style="display:none;">
  <div class="onboarding-content">
    <strong>Welcome to Gnoke OBD2</strong>
    <span>Select a connection mode and click Connect to start diagnosing your vehicle.</span>
    <button onclick="dismissOnboarding()" class="btn-secondary">Got it</button>
  </div>
</div>
```

```css
.onboarding {
  background: var(--accent-lt);
  border-bottom: 1px solid var(--accent);
  padding: 12px 20px;
}
.onboarding-content {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  font-size: 0.85rem;
}
.onboarding-content strong { color: var(--accent); }
```

---

## 7. SPECIFIC COMPONENT ANALYSIS

### 7.1 Dropdown Menus

**Rating: Good (7/10)**

The CSS-only hover/focus-within dropdowns work well but have issues:
- **Hover-only persistence:** Menu stays open as long as cursor is over it — good
- **Focus-within:** Keyboard users can Tab into the menu — good
- **No arrow key navigation:** Can't use ↑↓ to navigate menu items
- **No Escape to close:** Must Tab out or click elsewhere

### 7.2 Mobile Drawer

**Rating: Good (7/10)**

Well-implemented with:
- Smooth CSS transition
- Backdrop overlay with blur
- Escape key to close
- Click outside to close

**Missing:**
- Focus trap (tab cycles out of drawer)
- `aria-modal="true"` not set
- No swipe-to-close gesture

### 7.3 Toast Notification

**Rating: Fair (6/10)**

Good positioning and animation. Issues:
- Only one toast at a time — new toast overwrites previous
- No persistence for errors (auto-dismiss after timeout would be better for errors)
- No action buttons (e.g., "Undo" for clear operations)

### 7.4 Config Advanced Section

**Rating: Excellent (9/10)**

The `<details>` element for progressive disclosure is a well-chosen native HTML pattern. The chevron animation, summary styling, and hint text are all well-executed.

---

## 8. SUMMARY & PRIORITIZED RECOMMENDATIONS

### Critical (Must Fix)

| # | Issue | File | Effort |
|---|-------|------|--------|
| 1 | Dark theme muted text contrast fails (2.14:1) — unreadable | `style.css` | Small |
| 2 | Dark theme red DTC text fails (2.46:1) — primary content invisible | `style.css` | Small |
| 3 | Dark theme accent on bg fails (2.23:1) | `style.css` | Small |
| 4 | `#conn-btn` is hidden — primary CTA invisible | `index.html` | Small |
| 5 | No focus indicators on buttons | `style.css` | Small |

### High Priority

| # | Issue | File | Effort |
|---|-------|------|--------|
| 6 | Missing ARIA labels, live regions, focus trap | `index.html` | Medium |
| 7 | Loading/feedback states missing on all actions | `script.js` + components | Medium |
| 8 | Empty states missing (Freeze Frame, VIN) | `index.html` | Small |
| 9 | `alert()` blocks UI on errors | `script.js` | Small |
| 10 | SVG gauges lack text alternatives | `index.html` | Small |

### Medium Priority

| # | Issue | File | Effort |
|---|-------|------|--------|
| 11 | `prefers-reduced-motion` not supported | `style.css` | Small |
| 12 | Dashboard layout not responsive | `style.css` | Small |
| 13 | No DTC search/filter | New feature | Medium |
| 14 | No keyboard shortcuts | New feature | Small |
| 15 | No onboarding for first-time users | New feature | Medium |
| 16 | Canvas not Retina-optimized | `script.js` | Small |

### Low Priority

| # | Issue | File | Effort |
|---|-------|------|--------|
| 17 | Print styles missing | `style.css` | Small |
| 18 | No scan history/comparison | New feature | Large |
| 19 | Toast overwrite limitation | `script.js` | Small |
| 20 | Breadcrumb navigation | `index.html` | Small |

---

## Appendix: Recommended CSS Patches

Apply these as a single patch file (`accessibility-fixes.css`) that loads after `style.css`:

```css
/* ================================================================
   Gnoke OBD2 — Accessibility & UX Hotfixes
   Load after style.css to override without modifying source
   ================================================================ */

/* ── CRITICAL: Dark theme contrast fixes ── */
[data-theme="dark"] {
  --muted:     #a8947e;   /* 4.58:1 on bg, was 2.25:1 */
  --red:       #d45545;   /* 4.58:1 on surface, was 2.46:1 */
  --green:     #6ba35a;   /* 5.1:1 on bg, was 3.19:1 */
  --blue:      #4a8ec4;   /* 4.7:1 on bg, was 2.90:1 */
  --accent:    #c46a5a;   /* 4.6:1 on bg, was 2.23:1 */
  --border:    #3d2e1e;   /* subtle improvement */
}

/* ── HIGH: Universal focus indicators ── */
*:focus { outline: none; }
*:focus-visible {
  outline: 2.5px solid var(--accent);
  outline-offset: 2px;
  border-radius: var(--radius-sm);
}
[data-theme="dark"] *:focus-visible {
  outline-color: #c46a5a;
}
.menu-content button:focus-visible {
  outline-offset: -2px;
}

/* ── HIGH: Show conn-btn in topbar ── */
#conn-btn { display: inline-block !important; }
#mode { display: inline-block !important; max-width: 120px; }

/* ── MEDIUM: Reduced motion ── */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

/* ── MEDIUM: Skip link ── */
.skip-link {
  position: absolute; top: -40px; left: 0;
  background: var(--accent); color: #fff;
  padding: 8px 16px; z-index: 1000;
  transition: top 0.15s;
}
.skip-link:focus { top: 0; }

/* ── MEDIUM: Screen reader only utility ── */
.sr-only {
  position: absolute; width: 1px; height: 1px;
  padding: 0; margin: -1px; overflow: hidden;
  clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0;
}

/* ── MEDIUM: Loading spinner on buttons ── */
.btn-primary.loading,
.btn-secondary.loading {
  opacity: 0.7;
  cursor: wait;
  position: relative;
}

/* ── LOW: Print styles ── */
@media print {
  #topbar, #drawer, #drawer-overlay, .page-header-actions,
  .recorder-controls, .icon-btn, #theme-toggle { display: none !important; }
  .view { position: static !important; overflow: visible !important; }
  .dtc-card { break-inside: avoid; border: 1px solid #999 !important; }
  body { background: #fff !important; color: #000 !important; }
}

/* ── MEDIUM: Dashboard responsive fixes ── */
.gauge-container svg {
  width: clamp(140px, 35vw, 200px);
  height: clamp(140px, 35vw, 200px);
}

/* ── MEDIUM: Retina canvas fix ── */
#data-chart {
  width: 100%;
  height: auto;
  aspect-ratio: 4 / 1;
  max-height: 200px;
}
```

---

*Report generated by UI/UX analysis of Gnoke OBD2 v2.5 codebase (GitHub: edmundsparrow/Gnoke-OBD2)*
