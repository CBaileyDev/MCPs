# Garage Copilot — Deep Code Architecture & Quality Analysis

**Analyst**: Senior TypeScript/Electron Architect  
**Scope**: Full codebase across `garage-copilot` engine library and `garage-copilot-desktop` Electron app  
**Methodology**: Static architecture analysis, pattern assessment, async-flow inspection, test-coverage evaluation, maintainability scoring  

---

## 1. Executive Summary

| Dimension | Score | Verdict |
|---|---|---|
| **Architecture / Separation of Concerns** | 5.5/10 | Clean engine/desktop split; monolithic renderer UI undermines it |
| **TypeScript Type Safety** | 6/10 | Good structural types; explicit `any` missing, but implicit weakening present |
| **Error Handling** | 4/10 | Swallowed errors, no top-level boundaries, silent transport failures |
| **State Management** | 3.5/10 | Global mutable heap in `app.ts`; no unmount/cleanup guarantees |
| **Testing** | 4/10 | Unit tests exist for formatting only; zero integration or UI tests |
| **Async Patterns** | 5/10 | Basic `inFlight` guard but no cancellation, leaking pumps, timer orphans |
| **Maintainability** | 5/10 | ~600-line UI monolith, magic numbers, missing docs, tight coupling |

**Overall Assessment**: The engine library (`garage-copilot`) has a well-designed transport abstraction and good protocol-layer separation. The Electron renderer, however, is a classic "one-file-writes-it-all" accumulation that represents significant technical debt. Critical issues exist in async cleanup, error propagation, and test coverage.

---

## 2. Detailed Findings by Severity

### 2.1 CRITICAL

---

#### CRIT-001: `pump()` Read Loop Lacks Error Recovery — `web-serial.ts`

**Issue**: The `pump()` method has no `try/catch` around `reader.read()`. A single USB disconnect or `DOMException` (e.g., `NetworkError` from the Serial API) will reject the promise, exit the loop silently, and leave `pumpDone` resolved (not rejected). The transport appears "open" but is dead.

```typescript
// CURRENT (fragile)
private async pump(): Promise<void> {
  while (!this.closed) {
    const { value, done } = await reader.read(); // ← throws on USB disconnect
    if (done) break;
    const text = this.decoder.decode(value, { stream: true });
    for (const listener of this.listeners) listener(text);
  }
}
```

**Impact**: After any transport-level error, the UI shows "connected" but receives no data. No user-visible error is produced. The only recovery is manual reconnect.

**Recommendation**:
```typescript
private async pump(): Promise<void> {
  try {
    while (!this.closed) {
      try {
        const { value, done } = await this.reader!.read();
        if (done) break;
        const text = this.decoder.decode(value, { stream: true });
        for (const listener of this.listeners) listener(text);
      } catch (chunkErr) {
        if (this.closed) break; // expected during close
        this.emit('error', new TransportError('Read failure', { cause: chunkErr }));
        // Optional: exponential backoff retry before breaking
        break;
      }
    }
  } finally {
    this.cleanupInternal(); // release locks, nullify reader/writer
  }
}
```

**Also Required**: Add an `'error'` event mechanism to `ObdTransport` interface so upstream code can observe transport death.

---

#### CRIT-002: Live Timer Orphaning & No Cancellation — `app.ts`

**Issue**: `liveTimer` is stored as a raw `number | null` but there is no evidence of cleanup on:
- Window unload / beforeunload
- Connection teardown
- Tab visibility changes

```typescript
// CURRENT — no cleanup paths shown
let liveTimer: number | null = null;
const tick = async (): Promise<void> => { /* ... */ };
// setInterval(tick, 1000) implied but cleanup not shown
```

**Impact**: (a) Reloading the renderer leaks intervals; (b) navigating away mid-promise leaves `inFlight = true` permanently, freezing live monitoring.

**Recommendation**:
```typescript
const liveLoop = {
  timer: null as ReturnType<typeof setInterval> | null,
  abort: new AbortController(),
  inFlight: false,

  start(client: ObdReader) {
    this.stop();
    this.abort = new AbortController();
    this.timer = setInterval(() => this.tick(client), 1000);
  },

  async tick(client: ObdReader) {
    if (this.inFlight) return;
    this.inFlight = true;
    try {
      for (const pid of LIVE_PIDS) {
        if (this.abort.signal.aborted) break;
        try {
          const decoded = await client.readLivePid(pid);
          // ...
        } catch (e) {
          if ((e as Error).name === 'AbortError') break;
          // log, don't swallow silently
        }
      }
    } finally {
      this.inFlight = false;
    }
  },

  stop() {
    this.abort.abort();
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    this.inFlight = false;
  }
};

// Wire to lifecycle
window.addEventListener('beforeunload', () => liveLoop.stop());
```

---

#### CRIT-003: Silent Error Swallowing in Live Poll Loop — `app.ts`

**Issue**: The `catch { /* skip this PID this round */ }` pattern discards **all** errors indiscriminately—including transport failures, protocol parse errors, and ELM327 fault responses. A dead transport looks identical to a missing PID.

```typescript
for (const pid of LIVE_PIDS) {
  try {
    const decoded = await c.client.readLivePid(pid);
    // ...
  } catch { /* skip this PID this round */ }  // ← black hole
}
```

**Impact**: Users have no feedback when the OBD adapter fails, is unplugged, or returns `UNABLE TO CONNECT`. The UI simply stops updating without warning.

**Recommendation**:
```typescript
interface PidPollResult {
  pid: string;
  ok: TimedSample | null;
  err: Error | null;
}

const MAX_CONSECUTIVE_PID_ERRORS = 3;
const pidErrorCounts = new Map<string, number>();

for (const pid of LIVE_PIDS) {
  try {
    const decoded = await c.client.readLivePid(pid);
    pidErrorCounts.set(pid, 0);
    // ... update UI ...
  } catch (err) {
    const count = (pidErrorCounts.get(pid) ?? 0) + 1;
    pidErrorCounts.set(pid, count);
    if (count >= MAX_CONSECUTIVE_PID_ERRORS) {
      showPidError(pid, err as Error); // surface in UI
    }
    // If transport-level error, propagate up to connection health check
    if (err instanceof TransportError) {
      handleConnectionFailure(err);
      break;
    }
  }
}
```

---

### 2.2 HIGH

---

#### HIGH-001: 600-Line UI Monolith with Multiple Responsibilities — `app.ts`

**Issue**: `app.ts` combines connection management, live monitoring (1Hz timer, 8 PIDs), diagnostic session orchestration, DTC display, trend rendering, DOM manipulation, event handling, and buffer management in a single file.

**Impact**: No unit testing is feasible without mocking the entire browser DOM + Electron IPC + serial stack. Changes to one feature risk regressions in unrelated features. Code review surface area is excessive.

**Recommendation**: Decompose into focused modules with explicit contracts:

```typescript
// modules/live-monitor.ts
export interface LiveMonitor {
  start(client: ObdReader, pids: string[]): void;
  stop(): void;
  onSample(cb: (s: TimedSample) => void): () => void;
  onError(cb: (err: Error) => void): () => void;
}

// modules/connection-manager.ts
export interface ConnectionManager {
  connect(transport: ObdTransport): Promise<Connection>;
  disconnect(): Promise<void>;
  readonly state: ConnectionState; // 'idle' | 'connecting' | 'connected' | 'error'
  onStateChange(cb: (s: ConnectionState) => void): () => void;
}

// modules/ui-controller.ts
// Binds DOM events → manager actions, renders based on manager state
```

Target: `app.ts` reduced to ~80 lines of composition/wiring code.

---

#### HIGH-002: Global Mutable State Without Encapsulation — `app.ts`

**Issue**: Top-level `let` declarations create an ungoverned global heap accessible from any closure:

```typescript
let conn: Connection | null = null;
let liveTimer: number | null = null;
let liveSamples: TimedSample[] = [];
let inFlight = false; // implied from context
const liveCards = new Map<string, LiveCard>();
const liveHistory = new Map<string, number[]>();
```

Any function can mutate `conn`, forget to reset `inFlight`, or replace `liveSamples` mid-iteration. No state-change auditing or reactivity.

**Impact**: Race conditions between connect/disconnect and live tick; state desynchronization between UI and data; impossible to debug state transitions.

**Recommendation**: Centralize in a finite-state-machine (FSM) pattern or lightweight store:

```typescript
type AppState =
  | { phase: 'idle' }
  | { phase: 'connecting'; transport: ObdTransport }
  | { phase: 'connected'; connection: Connection; monitor: LiveMonitor }
  | { phase: 'error'; cause: Error };

class AppStore extends EventTarget {
  private _state: AppState = { phase: 'idle' };

  get state(): AppState { return this._state; }

  transition(next: AppState): void {
    const prev = this._state;
    this._validateTransition(prev, next);
    this._state = next;
    this.dispatchEvent(new CustomEvent('change', { detail: { prev, next } }));
  }

  private _validateTransition(from: AppState, to: AppState): void {
    const allowed: Record<string, string[]> = {
      idle: ['connecting'],
      connecting: ['connected', 'error', 'idle'],
      connected: ['idle', 'error'],
      error: ['idle', 'connecting'],
    };
    if (!allowed[from.phase].includes(to.phase)) {
      throw new Error(`Invalid transition: ${from.phase} → ${to.phase}`);
    }
  }
}
```

---

#### HIGH-003: No Transport Close Cleanup — `web-serial.ts`

**Issue**: The `pumpDone` promise is created but never awaited during `stop()`/close. The `reader` and `writer` are not released through `releaseLock()`/`releaseLock()` on close.

```typescript
// Current pattern lacks:
// await this.pumpDone; — never waits for pump to finish
// this.reader.releaseLock(); — never releases
// this.writer.releaseLock(); — never releases
```

**Impact**: Calling `start()` after `stop()` (reconnect scenario) throws because the previous reader/writer still holds the streams locked. This is an unrecoverable error in the Web Streams API.

**Recommendation**:
```typescript
async stop(): Promise<void> {
  this.closed = true;
  this.reader?.cancel(new Error('Transport closing')).catch(() => {});
  await this.pumpDone; // wait for pump to exit
  this.reader?.releaseLock();
  this.writer?.releaseLock();
  await this.port.close();
}
```

---

#### HIGH-004: Magic Numbers Without Named Constants — `app.ts`, `trends.ts`

**Issue**: Multiple thresholds and limits are hardcoded without provenance:

| Location | Value | Meaning |
|----------|-------|---------|
| `app.ts` | `LIVE_SAMPLES_MAX = 4000` | Why 4000? ~66 min at 1Hz? |
| `app.ts` | `LOG_MAX = 240` | Why 240? |
| `app.ts` | `SPARK_MAX = 60` | Sparkline Y-axis cap |
| `app.ts` | `LIVE_PIDS.length = 8` | PIDs per tick |
| `trends.ts` | `110` | Coolant overheat threshold (°C?) |
| `trends.ts` | `13.0` | Low charging voltage threshold |
| `trends.ts` | `±10%`, `±25%` | Fuel trim watch/warn thresholds |

**Impact**: Maintenance engineers cannot determine if thresholds are SAE-specified, vehicle-class specific, or arbitrarily chosen. Changing one vehicle platform requires find-and-replace across files.

**Recommendation**: Extract to a tunable configuration object:

```typescript
// config/vehicle-profile.ts
export interface VehicleProfile {
  coolant: { overheatThresholdC: number };
  charging: { minVoltage: number; maxVoltage: number };
  fuelTrim: { watchPercent: number; warnPercent: number };
  ui: { liveSamplesMax: number; logMax: number; sparkMax: number };
}

export const GENERIC_PROFILE: VehicleProfile = {
  coolant: { overheatThresholdC: 110 }, // SAE J1979 typical
  charging: { minVoltage: 13.0, maxVoltage: 14.8 },
  fuelTrim: { watchPercent: 10, warnPercent: 25 },
  ui: { liveSamplesMax: 4000, logMax: 240, sparkMax: 60 },
};
```

---

#### HIGH-005: `trends.ts` Hardcodes PID Hex Strings Without Abstraction

**Issue**:
```typescript
const stft = recentAvg(byPid.get("06"));   // Short Term Fuel Trim — Bank 1
const ltft = recentAvg(byPid.get("07"));   // Long Term Fuel Trim — Bank 1
const coolant = byPid.get("05");           // Engine Coolant Temperature
const volt = byPid.get("42");              // Control Module Voltage
```

Raw hex strings `"06"`, `"07"`, `"05"`, `"42"` are used directly with no named constants or registry lookup. Cross-referencing requires external PID tables.

**Impact**: Typos cause silent failures (wrong PID analyzed). Adding new trend checks requires cross-referencing hex tables. New developers have no semantic context.

**Recommendation**: Use a PID registry:

```typescript
// obd/pid-registry.ts
export const PID = {
  ENGINE_RPM:          '0C',
  VEHICLE_SPEED:       '0D',
  COOLANT_TEMP:        '05',
  INTAKE_AIR_TEMP:     '0F',
  THROTTLE_POS:        '11',
  SHORT_TERM_FUEL_TRIM_B1: '06',
  LONG_TERM_FUEL_TRIM_B1:  '07',
  CONTROL_MODULE_VOLTAGE:  '42',
} as const;

// trends.ts
const stft = recentAvg(byPid.get(PID.SHORT_TERM_FUEL_TRIM_B1));
```

---

#### HIGH-006: Package.json TypeScript Version Mismatch

**Issue**: `"typescript": "^6.0.3"` — TypeScript has not released a 6.x version. Latest stable is 5.7.x. This is either a typo or an impossible dependency.

```json
"typescript": "^6.0.3"  // ← does not exist (as of 2024-2025)
```

**Impact**: `npm install` will fail or resolve to an unexpected version. CI builds are non-reproducible.

**Recommendation**: Pin to latest stable:
```json
"typescript": "~5.7.0"
```

---

### 2.3 MEDIUM

---

#### MED-001: No Evidence of `inFlight` Reset on Connection Loss — `app.ts`

**Issue**: If `conn` becomes `null` (disconnected) while `tick()` is mid-flight, the `finally` block resets `inFlight = false`, which is correct. However, if the tick throws before reaching the `finally` (e.g., `c.client` is dereferenced after a null assignment), `inFlight` may remain `true` forever.

**Recommendation**: Defensive guard:
```typescript
const tick = async (): Promise<void> => {
  const c = conn;
  if (!c || inFlight) return;
  inFlight = true;
  try {
    // all access through captured `c`, not global `conn`
  } catch (e) {
    handleLiveError(e);
  } finally {
    inFlight = false; // unconditional
  }
};
```

Also: ensure `conn = null` is always accompanied by `inFlight = false` via the state machine (HIGH-002).

---

#### MED-002: No Upper Bound on `liveHistory` Sparkline Data — `app.ts`

**Issue**: `liveHistory` is a `Map<string, number[]>` with no eviction policy. While `liveSamples` is bounded at 4000, `liveHistory` accumulates indefinitely per PID.

```typescript
const liveHistory = new Map<string, number[]>(); // ← no max length
```

**Impact**: Long monitoring sessions (hours of driving) bloat memory. Sparkline rendering slows as array length grows.

**Recommendation**:
```typescript
function boundedPush<T>(arr: T[], item: T, max: number): void {
  arr.push(item);
  if (arr.length > max) arr.shift();
}

// In updateCard:
const history = liveHistory.get(pid) ?? [];
boundedPush(history, value, SPARK_MAX); // or a dedicated SPARK_HISTORY_MAX
```

---

#### MED-003: `boundedPush` Mutates Then Copies — Potential Performance Issue

**Issue**: The shown pattern:
```typescript
boundedPush(liveSamples, { ... }, LIVE_SAMPLES_MAX);
```

If `boundedPush` uses `shift()` on a 4000-element array of objects, each eviction is O(n) due to array reindexing. For a 1Hz tick, this means a full array copy every second.

**Recommendation**: Use a ring buffer (circular buffer) for O(1) push and eviction:

```typescript
class RingBuffer<T> {
  private buffer: T[];
  private head = 0;
  private size = 0;
  constructor(readonly capacity: number) { this.buffer = new Array(capacity); }

  push(item: T): void {
    this.buffer[this.head] = item;
    this.head = (this.head + 1) % this.capacity;
    if (this.size < this.capacity) this.size++;
  }

  toArray(): T[] {
    const out: T[] = [];
    for (let i = 0; i < this.size; i++) {
      const idx = (this.head - this.size + i + this.capacity) % this.capacity;
      out.push(this.buffer[idx]);
    }
    return out;
  }
}
```

---

#### MED-004: `analyzeTrends` Lacks Time-Window Awareness

**Issue**: `recentAvg()` is called without a time-window parameter. The function name implies recency weighting, but the signature and behavior are opaque.

```typescript
const stft = recentAvg(byPid.get("06")); // ← all time? last N? last minute?
```

**Impact**: A 2-hour test drive has the same weight as a 30-second idle. Warnings may lag significantly or trigger from ancient data.

**Recommendation**: Explicit windowing:

```typescript
function recentAvg(series: number[], times: number[], windowMs: number): number | undefined {
  const cutoff = Date.now() - windowMs;
  let sum = 0, count = 0;
  for (let i = times.length - 1; i >= 0; i--) {
    if (times[i] < cutoff) break;
    sum += series[i];
    count++;
  }
  return count > 0 ? sum / count : undefined;
}
```

---

#### MED-005: Electron `preload.ts` Not Shown — Security Review Blocked

**Issue**: `preload.ts` is referenced in `main.ts` as the context-isolation bridge, but its code is not provided. Without review, we cannot verify:
- Whether `contextBridge.exposeInMainWorld` is used correctly
- Whether IPC channels are allowlisted
- Whether serial API permissions are properly gated

**Impact**: This is a potential security vulnerability vector. The permission handlers in `main.ts` are permissive:

```typescript
ses.setPermissionCheckHandler((_wc, permission) => permission === "serial");
ses.setDevicePermissionHandler(details => details.deviceType === "serial");
```

These grant **all** serial access to **all** frames without origin/device filtering.

**Recommendation**:
```typescript
const ALLOWED_ORIGINS = ['file://', 'garage-copilot://']; // or packaged app protocol

ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
  if (permission !== 'serial') return false;
  return ALLOWED_ORIGINS.some(o => requestingOrigin.startsWith(o));
});

ses.setDevicePermissionHandler((details) => {
  if (details.deviceType !== 'serial') return false;
  // Optional: maintain allowlist of known OBD adapter vendor IDs
  const knownObdVendors = [0x0403, 0x067B]; // FTDI, Prolific
  return knownObdVendors.includes(details.vendorId);
});
```

Also: expose only required APIs through `preload.ts`:

```typescript
// preload.ts
import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('electronAPI', {
  // Only needed if main-renderer IPC is used beyond Web Serial
  platform: process.platform,
});
```

---

#### MED-006: No Diagnostic Session Timeout or Cancellation — `diagnose/session.ts`

**Issue**: Not shown in snippets, but implied by `session.ts` existence. Diagnostic scans over OBD-II can take 30-120 seconds. Without a timeout or `AbortSignal`, a stuck adapter hangs the UI indefinitely.

**Recommendation**: All long-running OBD operations should accept `AbortSignal`:

```typescript
// obd/elm327.ts
async readPid(pid: string, signal?: AbortSignal): Promise<DecodedPid>;

// diagnose/session.ts
async runSession(client: ObdReader, signal: AbortSignal): Promise<DiagnosticReport> {
  const pids = await client.getSupportedPids(signal);
  for (const pid of pids) {
    if (signal.aborted) throw new Error('Diagnostic session cancelled');
    results.push(await client.readPid(pid, signal));
  }
}
```

---

### 2.4 LOW

---

#### LOW-001: Missing Return Type on `tick()` — `app.ts`

**Issue**: `const tick = async (): Promise<void> => { ... }` is explicit, which is good. However, internal helper functions likely lack explicit returns throughout the 600-line file.

**Recommendation**: Enable `"noImplicitAny": true` and `"strictFunctionTypes": true` in `tsconfig.json`, and add explicit return types to all exported/public functions.

---

#### LOW-002: `demo` Flag in Connection Type is a Primitive Obsession Smell

```typescript
type Connection = { client: ObdReader; label: string; demo: boolean };
```

**Issue**: Boolean flags for mode selection are a maintenance burden. Adding a third mode (e.g., `replay`) requires changing the type and all conditional branches.

**Recommendation**: Use a discriminated union:

```typescript
type Connection =
  | { kind: 'live'; client: ObdReader; label: string; transport: ObdTransport }
  | { kind: 'demo'; client: ObdReader; label: string }
  | { kind: 'replay'; client: ObdReader; label: string; source: string };
```

---

#### LOW-003: `renderFlags` is Called Every Tick Regardless of Changes — `app.ts`

**Issue**: `renderFlags()` executes inside the tick loop even when no flag state has changed. This causes unnecessary DOM queries and repaints.

**Recommendation**: Cache last-rendered flag state and diff:

```typescript
let lastFlagDigest = '';
function renderFlagsIfChanged(flags: Flag[]) {
  const digest = flags.map(f => `${f.kind}:${f.severity}`).join('|');
  if (digest === lastFlagDigest) return;
  lastFlagDigest = digest;
  renderFlags(flags);
}
```

---

#### LOW-004: `styles.css` is a Single File — No Component Scoping

**Issue**: All styles in one global CSS file risk selector collisions as the app grows.

**Recommendation**: Consider CSS modules or at minimum a BEM naming convention:
```css
.live-monitor__card { }
.live-monitor__card--warning { }
.live-monitor__sparkline { }
```

---

#### LOW-005: Missing `web-serial.test.ts` Coverage for Error Paths

**Issue**: Tests exist for WebSerial (per file listing), but `pump()` error handling, close cleanup, and reconnect scenarios are likely untested given the code structure.

**Recommendation**: Add tests for:
- `reader.read()` throwing `NetworkError`
- Double `start()` call (should error or clean previous)
- `stop()` while `pump()` is mid-read
- Listener removal via returned unsubscribe

---

## 3. Architecture Pattern Assessment

### 3.1 Transport Abstraction (Strong)

The `ObdTransport` interface with `WebSerialTransport`, `SerialTransport`, `ReplayTransport`, and `Simulator` implementations is well-designed. It correctly decouples the protocol layer (ELM327 AT commands) from I/O.

```
┌─────────────────────────────────────────┐
│           Diagnose / Monitor            │
│          (session.ts, trends.ts)        │
├─────────────────────────────────────────┤
│           Protocol Layer                │
│  (elm327.ts, pid-formulas.ts, dtc)      │
├─────────────────────────────────────────┤
│     ObdTransport Interface              │
│  ┌──────────┬──────────┬──────────┐     │
│  │ WebSerial│  Serial  │  Replay  │     │
│  │Transport │Transport │Transport │     │
│  └──────────┴──────────┴──────────┘     │
└─────────────────────────────────────────┘
```

**Verdict**: Keep this pattern. Consider adding an `'error'` event to `ObdTransport` for upstream propagation (CRIT-001).

### 3.2 Renderer State Architecture (Weak)

The renderer is a flat imperative script rather than a component-based or layered architecture:

```
CURRENT:                              RECOMMENDED:
┌──────────────┐                     ┌──────────────┐
│   app.ts     │                     │   app.ts     │  ← wiring only
│  ~600 lines  │                     │  ~80 lines   │
│  (everything)│                     ├──────────────┤
└──────────────┘                     │ Connection   │
                                     │   Manager    │
                                     ├──────────────┤
                                     │ Live Monitor │
                                     ├──────────────┤
                                     │  DOM Controller│
                                     ├──────────────┤
                                     │  Trend Renderer│
                                     └──────────────┘
```

### 3.3 Engine/Desktop Boundary (Good)

The `core.ts` re-export pattern correctly keeps renderer logic out of the engine:

```typescript
// renderer/core.ts
export * from 'garage-copilot';
```

The IPC type definitions in `shared/ipc.ts` are appropriately placed for type-safe main/renderer communication.

---

## 4. Testing Strategy Assessment

### 4.1 Current Coverage (Estimated)

| File | Has Tests | Coverage Estimate |
|------|-----------|-------------------|
| `format.test.ts` | ✅ | ~100% of format.ts |
| `web-serial.test.ts` | ✅ | Likely happy-path only |
| `pid-formulas.ts` | ❌ | **0%** — critical safety code |
| `dtc-decode.ts` | ❌ | **0%** — critical safety code |
| `elm327.ts` | ❌ | **0%** — protocol parser |
| `trends.ts` | ❌ | **0%** — analysis engine |
| `app.ts` | ❌ | **0%** — all UI logic |
| `session.ts` | ❌ | **0%** — diagnostic orchestration |
| `main.ts` | ❌ | **0%** — Electron main |
| `preload.ts` | ❌ | **0%** — security bridge |

### 4.2 Priority Test Additions

1. **PID formula correctness**: Every formula in `pid-formulas.ts` must have unit tests with known SAE J1979 test vectors.
2. **DTC decode round-trip**: Encode → decode tests for all DTC categories (P0xxx, P1xxx, B0xxx, C0xxx, U0xxx).
3. **ELM327 protocol parser**: Test with captured real-world adapter responses including `NO DATA`, `ERROR`, `UNABLE TO CONNECT`, multi-frame responses.
4. **Trend analysis**: Inject known time series, assert expected flag outputs.
5. **Transport error recovery**: Mock `ReadableStream` that throws; assert transport state and error events.

---

## 5. Async Pattern Deep Dive

### 5.1 Race Condition: `inFlight` + Connection Teardown

```
T0: tick() starts, inFlight = true
T1: User clicks Disconnect → conn = null
T2: tick() resumes, tries c.client.readLivePid()
    → 'Cannot read properties of null' OR
    → reads from stale captured `c` (not null-checked again)
T3: finally { inFlight = false }  ← correct, but state is inconsistent
```

**Fix**: AbortController pattern (CRIT-002) + state machine transitions that wait for `inFlight === false` before completing disconnect.

### 5.2 Promise Leak: `pumpDone` Never Awaited

```typescript
this.pumpDone = this.pump(); // Promise stored but never consumed
```

If `pump()` rejects, the rejection is unhandled until `stop()` is called—and `stop()` may not await it. This creates an unhandled promise rejection in Node.js/Electron.

**Fix**: Attach a catch handler or ensure `stop()` always awaits:

```typescript
this.pumpDone = this.pump().catch(err => {
  if (!this.closed) this.emit('error', err);
});
```

### 5.3 No Backpressure on Serial Data

The `pump()` loop calls listeners synchronously for every chunk. If the renderer is busy (DOM repaint), OBD responses pile up in memory. The Web Streams API has built-in backpressure (`reader.read()` pauses when downstream queues fill), but the listener pattern bypasses it.

**Fix**: Use a pull-based or queued model:

```typescript
private async pump(): Promise<void> {
  while (!this.closed) {
    const { value, done } = await this.reader!.read();
    if (done) break;
    const text = this.decoder.decode(value, { stream: true });
    this.buffer += text;
    // Emit only complete lines (ELM327 uses \r\r> prompt)
    const lines = this.buffer.split(/\r\r>|\r\n/);
    this.buffer = lines.pop()!; // incomplete line stays in buffer
    for (const line of lines) {
      if (line.trim()) this.onLine(line.trim());
    }
  }
}
```

---

## 6. Maintainability Scorecard

| Metric | Value | Grade |
|--------|-------|-------|
| Largest file (app.ts) | ~600 lines | D |
| Average file size (estimated) | ~120 lines | B |
| Magic constants count | 12+ | D |
| Test-to-source ratio | ~2 files / 15+ files | F |
| Explicit `any` usage | Low (good) | B |
| JSDoc / inline docs | Not shown | D |
| Public API surface docs | Not shown | F |
| Type coverage | ~85% (estimated) | C |

---

## 7. Action Plan (Prioritized)

### Sprint 1 — Stability
| ID | Task | Files |
|----|------|-------|
| CRIT-001 | Add error recovery to `pump()` + transport error events | `web-serial.ts`, `serial-transport.ts` |
| CRIT-002 | Implement live monitor lifecycle with AbortController | `app.ts` |
| CRIT-003 | Classify and propagate errors in live poll loop | `app.ts` |
| HIGH-003 | Fix transport close cleanup (release locks, await pump) | `web-serial.ts` |

### Sprint 2 — Architecture
| ID | Task | Files |
|----|------|-------|
| HIGH-001 | Decompose `app.ts` into modules | New: `live-monitor.ts`, `connection-manager.ts`, `ui-controller.ts` |
| HIGH-002 | Implement AppState FSM | `app.ts` (or new `state.ts`) |
| MED-006 | Add AbortSignal to diagnostic session | `session.ts`, `elm327.ts` |
| MED-003 | Replace array shifting with ring buffer | `app.ts` |

### Sprint 3 — Quality
| ID | Task | Files |
|----|------|-------|
| HIGH-004 | Extract vehicle profile configuration | New: `config/` |
| HIGH-005 | Replace raw hex strings with PID registry | `obd/pid-registry.ts`, all consumers |
| MED-004 | Add time-windowed trend analysis | `trends.ts` |
| LOW-001 | Enable strict TypeScript, add return types | `tsconfig.json`, all files |

### Sprint 4 — Testing
| ID | Task | Files |
|----|------|-------|
| — | PID formula unit tests with SAE vectors | `pid-formulas.test.ts` |
| — | DTC decode round-trip tests | `dtc-decode.test.ts` |
| — | ELM327 parser tests with real adapter captures | `elm327.test.ts` |
| — | Transport error recovery tests | `web-serial.test.ts` |
| — | Trend analysis property-based tests | `trends.test.ts` |

---

*End of Analysis Report*
